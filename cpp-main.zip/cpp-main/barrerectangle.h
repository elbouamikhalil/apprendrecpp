#ifndef BARRERECTANGLE_H
#define BARRERECTANGLE_H
#include <string>
#include <iostream>
#include "barre.h"
using namespace std;

class BarreRectangle : public Barre
{
public:
    BarreRectangle(string _reference,  const int longueur, const int _densite, string _nom, const int _largeur);
    float CalculerSection();
    float CalculerMasse();

protected:
    string reference;
    int largeur;
    int longueur;
    int densite;
    string nom;
};

#endif // BARRERECTANGLE_H
