#include "barreronde.h"
#include <iostream>
#include <math.h>

using namespace std;



BarreRonde::BarreRonde(string _reference, const int _longueur, const int _densite, string _nom, const int diametre ):

    Barre(_reference, _longueur, _densite, _nom),
    diametre(diametre)
{
    cout << "constructeur de la classe Barre Ronde"<< endl;
}

float BarreRonde::CalculerSection()
{
  return ((M_1_PI * diametre *diametre)/4);
}

float BarreRonde::CalculerMasse()
{
 return CalculerSection() * longueur * densite;
}

