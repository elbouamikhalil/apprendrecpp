#include "barre.h"
#include <iostream>

Barre::Barre(string _reference, const int _longueur, const int _densite, string _nom):
    reference(_reference),
    longueur(_longueur),
    densite(_densite),
    nom(_nom)
{
cout << "constructeur de la classe Barre"<< endl;
}



void Barre::AfficherCaracteristiques()
{
    cout << "la reference est de: " << reference << endl;
    cout << "la longueur est de: " << longueur << endl;
    cout << "la densite est de: " << densite<< endl;
    cout << "le nom de l'alliage est: " << nom << endl;
}
