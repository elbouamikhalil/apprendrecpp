#include "barrecarre.h"
#include <iostream>
#include <math.h>

using namespace std;



BarreCarre::BarreCarre(string _reference, const int _longueur, const int _densite, string _nom, const int longueurcote ):

    Barre(_reference, _longueur, _densite, _nom),
    longueurcote(longueurcote)
{
    cout << "constructeur de la classe Barre carre"<< endl;
}

float BarreCarre::CalculerSection()
{
  return (longueurcote * longueurcote);
}

float BarreCarre::CalculerMasse()
{
 return CalculerSection() * longueurcote * densite;
}

