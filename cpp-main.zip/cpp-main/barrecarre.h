#ifndef BARRECARRE_H
#define BARRECARRE_H
#include <string>
#include <iostream>
#include "barre.h"
using namespace std;

class BarreCarre : public Barre
{
public:
    BarreCarre(string _reference,  const int longueur, const int _densite, string _nom, const int _longueurcote);
    float CalculerSection();
    float CalculerMasse();

protected:
    string reference;
    int longueurcote;
    int longueur;
    int densite;
    string nom;
};

#endif // BARRECARRE_H
