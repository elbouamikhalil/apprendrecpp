#ifndef BARRERONDE_H
#define BARRERONDE_H
#include <string>
#include <iostream>
#include "barre.h"
using namespace std;

class BarreRonde : public Barre
{
public:
    BarreRonde(string _reference,  const int longueur, const int _densite, string _nom, const int _diametre);
    float CalculerSection();
    float CalculerMasse();

protected:
    string reference;
    int diametre;
    int longueur;
    int densite;
    string nom;
};

#endif // BARRERONDE_H
