#include "barrerectangle.h"
#include <iostream>
#include <math.h>

using namespace std;



BarreRectangle::BarreRectangle(string _reference, const int _longueur, const int _densite, string _nom, const int largeur ):

    Barre(_reference, _longueur, _densite, _nom),
    largeur(largeur)
{
    cout << "constructeur de la classe Barre carre"<< endl;
}

float BarreRectangle::CalculerSection()
{
  return (largeur * longueur);
}

float BarreRectangle::CalculerMasse()
{
 return CalculerSection() * longueur * densite;
}

